﻿using Microsoft.EntityFrameworkCore;
using Rentify.Models;


namespace Rentify.Context
{
    public class RentifyContext : DbContext
    {
         public DbSet<User> Users { get; set; }
         public DbSet<Property> Properties { get; set; }

         public RentifyContext(DbContextOptions<RentifyContext> options) : base(options) { }
        


    }
}

