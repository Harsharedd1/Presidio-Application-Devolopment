﻿namespace Rentify.Models
{
    public class Property
    {
        public int Id { get; set; }
        public string Place { get; set; }
        public int Area { get; set; }
        public int Bedrooms { get; set; }
        public int Bathrooms { get; set; }
        public string NearbyHospitals { get; set; }
        public string NearbyColleges { get; set; }
        public int Price { get; set; }
        public string PropertyType { get; set; }
        public string Description { get; set; }
        public int SellerId { get; set; }
        public User Seller { get; set; }
    }
}
